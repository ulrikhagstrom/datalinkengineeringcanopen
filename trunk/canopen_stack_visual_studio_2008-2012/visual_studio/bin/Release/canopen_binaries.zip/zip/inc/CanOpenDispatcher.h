DWORD WINAPI  canopenDispatcher(PVOID p);
void sleepNoMessageFromCanInterface(int ms);
void sleepProcessedCanInterface(int ms);